﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Ви ввели число " + Console.ReadLine());
    }
}