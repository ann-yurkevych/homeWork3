﻿using homework_2._2;

internal class Program
{
    private static void Main(string[] args)
    {
        Team team = new Team("team");
        Worker worker1 = new Manager("Sasha");
        worker1.WorkDay = "Monday";
        Worker worker2 = new Developer("Max");
        worker2.WorkDay = "Thusday";
        Worker worker3 = new Developer("Taras");
        worker3.WorkDay = "Sunday";
        Worker worker4 = new Developer("Artem");
        worker4.WorkDay = "Friday";
        team.AddNewWorker(worker1);
        team.AddNewWorker(worker2);
        team.ShowDetailInfoAboutTeam();
        team.AddNewWorker(worker3);
        team.AddNewWorker(worker4);
        team.ShowDetailInfoAboutTeam();
    }
}