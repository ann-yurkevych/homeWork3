﻿namespace System.Collections
{
    internal class List<T>
    {
        public List()
        {
        }
    }
}