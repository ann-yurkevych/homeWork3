﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework_2._2
{
    internal class Developer : Worker
    {
        public Developer(string name) : base(name)
        {
            base.Position = "Розробник"; 
        }

        public override void FillWorkDay()
        {
            WriteCode();
            Call();
            Relax();
            WriteCode();
        }
    }
}
