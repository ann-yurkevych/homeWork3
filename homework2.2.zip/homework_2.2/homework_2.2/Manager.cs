﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework_2._2
{
    internal class Manager : Worker
    {
        private Random random = new Random();
        public Manager(string name) : base(name)
        {
            base.Position = "Менеджер";
        }

        public override void FillWorkDay()
        {
            for (int i = 0; i < random.Next(11); i++)
            {
                base.Call();
            }
            Relax();
            for (int i = 0; i < random.Next(6); i++)
            {
                base.Call();
            }
        }
    }
}
